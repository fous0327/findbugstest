public class Helloworld {
    public static void main(String[] args) {
        Person jack = new Person(10);
        jack.getAge();
        jack.getAge();
        jack.getAge();
    }
}

class Person {
    private int age;
    public Person(int age) {
        this.age = age;
    }
    public void getAge() {
        System.out.println(this.age);
    }
}