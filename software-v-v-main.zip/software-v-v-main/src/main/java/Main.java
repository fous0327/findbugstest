import javax.swing.*;
import java.awt.*;


public class Main {

    public static void main(String[] args) {
        int a = 3;
        int b = 4;
        int c = addFunc(a, b);
    }


    private int addFunc(int a, int b){
        return a+b;
    }
}